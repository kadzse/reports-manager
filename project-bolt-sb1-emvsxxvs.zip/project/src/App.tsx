import { useState, useEffect, useCallback } from "react";
import { supabase } from "./lib/supabase";
import type { Session } from "@supabase/supabase-js";
import {
  LayoutDashboard,
  Building2,
  Settings,
  LogOut,
  Bell,
  Search,
  Plus,
  Trash2,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  TrendingDown,
  CheckCircle2,
  Clock,
  AlertTriangle,
  X,
  ChevronDown,
} from "lucide-react";

type Lang = "ru" | "uz" | "en";
type Regime = "general" | "simplified";
type TabKey = "tax" | "fin" | "stat" | "hr";

interface Company {
  id: string;
  name: string;
  inn: string;
  regime: Regime;
  submissions: Record<string, boolean>;
}

interface Report {
  id: string;
  ru: string;
  uz: string;
  en: string;
  type: "monthly" | "quarterly" | "annual" | "event";
  dd?: number;
  off?: number;
  dm?: number;
}

const T = {
  ru: {
    app: "ReportAdmin",
    login: "Войти",
    signup: "Регистрация",
    uname: "Email",
    pwd: "Пароль",
    err: "Неверный логин или пароль",
    switchToSignup: "Нет аккаунта? Зарегистрироваться",
    switchToLogin: "Уже есть аккаунт? Войти",
    nav: { dash: "Главная", cos: "Компании", set: "Настройки" },
    logout: "Выйти",
    addCo: "Добавить компанию",
    coName: "Название",
    inn: "ИНН",
    regime: "Режим налогообложения",
    gen: "Общеустановленный",
    sim: "Упрощённый (НСО)",
    save: "Сохранить",
    cancel: "Отмена",
    back: "Назад",
    delCo: "Удалить",
    delQ: "Удалить компанию?",
    sub: "Сдан",
    noSub: "Не сдан",
    over: "Просрочен",
    d1: "Срок завтра",
    d3: "Через 3 дня",
    tabs: { tax: "Налоговые", fin: "Финансовые", stat: "Статистические", hr: "Кадровые" },
    st: { cos: "Компаний", due: "К сдаче", done: "Сдано", overdue: "Просрочено" },
    noCos: "Нет компаний",
    addF: "Добавьте первую компанию",
    alerts: "Срочные уведомления",
    ms: ["Янв","Фев","Мар","Апр","Май","Июн","Июл","Авг","Сен","Окт","Ноя","Дек"],
    monthly: "Ежемесячно",
    quarterly: "Ежеквартально",
    annual: "Ежегодно",
    event: "По факту",
    of: "из",
    allDone: "Все сданы",
    open: "Открыть",
    report: "Отчёт",
    frequency: "Периодичность",
    deadline: "Срок",
    status: "Статус",
    company: "Компания",
    search: "Поиск...",
    recentActivity: "Последние отчёты",
    submissionRate: "Процент сдачи",
    fromLastMonth: "с прошлого месяца",
  },
  uz: {
    app: "ReportAdmin",
    login: "Kirish",
    signup: "Ro'yxatdan o'tish",
    uname: "Email",
    pwd: "Parol",
    err: "Noto'g'ri login yoki parol",
    switchToSignup: "Akkaunt yo'qmi? Ro'yxatdan o'ting",
    switchToLogin: "Akkaunt bormi? Kiring",
    nav: { dash: "Bosh sahifa", cos: "Kompaniyalar", set: "Sozlamalar" },
    logout: "Chiqish",
    addCo: "Kompaniya qo'shish",
    coName: "Nomi",
    inn: "INN",
    regime: "Soliq rejimi",
    gen: "Umumiy belgilangan",
    sim: "Soddalashtirilgan (NSO)",
    save: "Saqlash",
    cancel: "Bekor qilish",
    back: "Orqaga",
    delCo: "O'chirish",
    delQ: "Kompaniyani o'chirish?",
    sub: "Topshirilgan",
    noSub: "Topshirilmagan",
    over: "Muddati o'tgan",
    d1: "Ertaga muddat",
    d3: "3 kunda muddat",
    tabs: { tax: "Soliq", fin: "Moliyaviy", stat: "Statistik", hr: "Kadrlar" },
    st: { cos: "Kompaniyalar", due: "Topshiriladigan", done: "Topshirilgan", overdue: "Muddati o'tgan" },
    noCos: "Kompaniyalar yo'q",
    addF: "Birinchi kompaniyani qo'shing",
    alerts: "Shoshilinch bildirishnomalar",
    ms: ["Yan","Fev","Mar","Apr","May","Iyn","Iyl","Avg","Sen","Okt","Noy","Dek"],
    monthly: "Oylik",
    quarterly: "Choraklik",
    annual: "Yillik",
    event: "Voqeaga ko'ra",
    of: "dan",
    allDone: "Barchasi topshirilgan",
    open: "Ochish",
    report: "Hisobot",
    frequency: "Davomiylik",
    deadline: "Muddat",
    status: "Holat",
    company: "Kompaniya",
    search: "Qidirish...",
    recentActivity: "So'nggi hisobotlar",
    submissionRate: "Topshirish foizi",
    fromLastMonth: "o'tgan oydan",
  },
  en: {
    app: "ReportAdmin",
    login: "Log in",
    signup: "Sign up",
    uname: "Email",
    pwd: "Password",
    err: "Invalid credentials",
    switchToSignup: "No account? Sign up",
    switchToLogin: "Have an account? Log in",
    nav: { dash: "Dashboard", cos: "Companies", set: "Settings" },
    logout: "Log out",
    addCo: "Add company",
    coName: "Name",
    inn: "Tax ID",
    regime: "Tax regime",
    gen: "General",
    sim: "Simplified (NSO)",
    save: "Save",
    cancel: "Cancel",
    back: "Back",
    delCo: "Delete",
    delQ: "Delete company?",
    sub: "Submitted",
    noSub: "Not submitted",
    over: "Overdue",
    d1: "Due tomorrow",
    d3: "Due in 3 days",
    tabs: { tax: "Tax", fin: "Financial", stat: "Statistical", hr: "HR" },
    st: { cos: "Companies", due: "Due", done: "Submitted", overdue: "Overdue" },
    noCos: "No companies",
    addF: "Add your first company",
    alerts: "Urgent notifications",
    ms: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],
    monthly: "Monthly",
    quarterly: "Quarterly",
    annual: "Annual",
    event: "On event",
    of: "of",
    allDone: "All submitted",
    open: "Open",
    report: "Report",
    frequency: "Frequency",
    deadline: "Deadline",
    status: "Status",
    company: "Company",
    search: "Search...",
    recentActivity: "Recent Reports",
    submissionRate: "Submission Rate",
    fromLastMonth: "from last month",
  },
} as const;

function getRpts(r: Regime) {
  const tg: Report[] = [
    { id: "nds", ru: "НДС и акцизный налог", uz: "QQS va aksiz solig'i", en: "VAT & excise tax", type: "monthly", dd: 20, off: 1 },
    { id: "ndfl", ru: "НДФЛ и соц. налог", uz: "JDSH va ijtimoiy soliq", en: "Income & social tax", type: "monthly", dd: 15, off: 1 },
    { id: "profit", ru: "Налог на прибыль", uz: "Foyda solig'i", en: "Corporate income tax", type: "quarterly", dd: 20, off: 1 },
    { id: "prop", ru: "Налог на имущество", uz: "Mol-mulk solig'i", en: "Property tax", type: "annual", dm: 3, dd: 1 },
  ];
  const ts: Report[] = [
    { id: "turn", ru: "Налог с оборота", uz: "Aylanma solig'i", en: "Turnover tax", type: "monthly", dd: 15, off: 1 },
    { id: "ndfl", ru: "НДФЛ и соц. налог", uz: "JDSH va ijtimoiy soliq", en: "Income & social tax", type: "monthly", dd: 15, off: 1 },
  ];
  const fg: Report[] = [
    { id: "f1", ru: "Форма №1: Баланс", uz: "1-shakl: Balans", en: "Form 1: Balance sheet", type: "annual", dm: 3, dd: 1 },
    { id: "f2", ru: "Форма №2: Фин. результаты", uz: "2-shakl: Moliyaviy natijalar", en: "Form 2: Financial results", type: "annual", dm: 3, dd: 1 },
    { id: "f3", ru: "Форма №3: Движение ОС", uz: "3-shakl: Asosiy vositalar", en: "Form 3: Fixed assets", type: "annual", dm: 3, dd: 1 },
    { id: "f4", ru: "Форма №4: Ден. потоки", uz: "4-shakl: Pul oqimlari", en: "Form 4: Cash flow", type: "annual", dm: 3, dd: 1 },
    { id: "f5", ru: "Форма №5: Капитал", uz: "5-shakl: O'z kapitali", en: "Form 5: Equity", type: "annual", dm: 3, dd: 1 },
  ];
  const fs: Report[] = [
    { id: "f2a", ru: "Форма №2а: Дебиторка/кредиторка", uz: "2a-shakl: Debitor/kreditor", en: "Form 2a: Receivables/Payables", type: "annual", dm: 3, dd: 1 },
  ];
  const st: Report[] = [
    { id: "stm", ru: "Статистика деятельности (ежемес.)", uz: "Oylik faoliyat statistikasi", en: "Monthly activity statistics", type: "monthly", dd: 5, off: 1 },
    { id: "stl", ru: "Отчёт по труду и зарплате", uz: "Mehnat va ish haqi hisoboti", en: "Labor & payroll report", type: "monthly", dd: 5, off: 1 },
    { id: "stq", ru: "Квартальная статистика", uz: "Choraklik statistika", en: "Quarterly statistics", type: "quarterly", dd: 10, off: 1 },
  ];
  const hr: Report[] = [
    { id: "inps", ru: "Реестр ИНПС", uz: "INPS reestri", en: "INPS registry", type: "monthly", dd: 15, off: 1 },
    { id: "enst", ru: "ЕНСТ my.mehnat.uz", uz: "YEMTT my.mehnat.uz", en: "ENST my.mehnat.uz", type: "event", dd: 3, off: 0 },
  ];
  return { tax: r === "general" ? tg : ts, fin: r === "general" ? fg : fs, stat: st, hr };
}

function gPK(r: Report) {
  const n = new Date(), y = n.getFullYear(), m = n.getMonth() + 1;
  if (r.type === "monthly" || r.type === "event") return `${y}-${String(m).padStart(2, "0")}`;
  if (r.type === "quarterly") return `${y}-Q${Math.ceil(m / 3)}`;
  return `${y}`;
}

function gDL(r: Report) {
  const n = new Date(), y = n.getFullYear(), m = n.getMonth() + 1;
  if (r.type === "monthly" || r.type === "event") {
    let dm = m + (r.off || 0), dy = y;
    if (dm > 12) { dm -= 12; dy++; }
    return new Date(dy, dm - 1, r.dd);
  }
  if (r.type === "quarterly") {
    const q = Math.ceil(m / 3);
    let dm = q * 3 + (r.off || 1), dy = y;
    if (dm > 12) { dm -= 12; dy++; }
    return new Date(dy, dm - 1, r.dd);
  }
  return new Date(y + 1, (r.dm || 3) - 1, r.dd);
}

function dTo(d: Date) {
  const a = new Date(); a.setHours(0, 0, 0, 0);
  const b = new Date(d); b.setHours(0, 0, 0, 0);
  return Math.ceil((b.getTime() - a.getTime()) / 86400000);
}

function fD(d: Date, ms: readonly string[]) {
  return `${d.getDate()} ${ms[d.getMonth()]} ${d.getFullYear()}`;
}

// ── Bar chart data: submission counts per month ──────────────────────────────
function getBarData(cos: Company[], ms: readonly string[]) {
  const now = new Date();
  return Array.from({ length: 6 }, (_, i) => {
    const d = new Date(now.getFullYear(), now.getMonth() - 5 + i, 1);
    const y = d.getFullYear();
    const m = d.getMonth() + 1;
    const key = `${y}-${String(m).padStart(2, "0")}`;
    let count = 0;
    cos.forEach((co) => {
      Object.keys(co.submissions).forEach((k) => {
        if (k.includes(`__${key}`) && co.submissions[k]) count++;
      });
    });
    return { label: ms[d.getMonth()], value: count };
  });
}

export default function App() {
  const [lang, setLang] = useState<Lang>("ru");
  const [session, setSession] = useState<Session | null>(null);
  const [page, setPage] = useState("dash");
  const [sel, setSel] = useState<Company | null>(null);
  const [cos, setCos] = useState<Company[]>([]);
  const [modal, setModal] = useState(false);
  const [ready, setReady] = useState(false);
  const [search, setSearch] = useState("");
  const t = T[lang];

  useEffect(() => {
    let mounted = true;
    supabase.auth.getSession().then(({ data }) => {
      if (!mounted) return;
      setSession(data.session);
      setReady(true);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => {
      setSession(s);
      if (!s) { setCos([]); setSel(null); setPage("dash"); }
    });
    return () => { mounted = false; sub.subscription.unsubscribe(); };
  }, []);

  const loadCompanies = useCallback(async () => {
    if (!session?.user) return;
    const { data: rows } = await supabase
      .from("companies")
      .select("id, name, inn, regime, submissions(report_key, submitted)");
    if (!rows) return;
    const list: Company[] = rows.map((r: any) => ({
      id: r.id, name: r.name, inn: r.inn, regime: r.regime as Regime,
      submissions: Object.fromEntries((r.submissions || []).map((s: any) => [s.report_key, s.submitted])),
    }));
    setCos(list);
  }, [session]);

  useEffect(() => { if (session) loadCompanies(); }, [session, loadCompanies]);

  async function doLogin(email: string, pwd: string, isSignup: boolean) {
    if (isSignup) {
      const { error } = await supabase.auth.signUp({ email, password: pwd });
      return !error;
    }
    const { error } = await supabase.auth.signInWithPassword({ email, password: pwd });
    return !error;
  }

  async function doLogout() {
    await supabase.auth.signOut();
    setPage("dash"); setSel(null);
  }

  async function addCo(name: string, inn: string, regime: Regime) {
    if (!session?.user) return;
    const { data } = await supabase.from("companies")
      .insert({ name, inn, regime, user_id: session.user.id })
      .select("id, name, inn, regime").single();
    if (data) setCos((prev) => [...prev, { ...data, regime: data.regime as Regime, submissions: {} }]);
    setModal(false);
  }

  async function delCo(id: string) {
    await supabase.from("companies").delete().eq("id", id);
    setCos((prev) => prev.filter((c) => c.id !== id));
    if (sel?.id === id) { setPage("dash"); setSel(null); }
  }

  async function toggle(coId: string, rid: string, period: string) {
    const k = `${rid}__${period}`;
    const co = cos.find((c) => c.id === coId);
    if (!co) return;
    const isSub = !co.submissions[k];
    const update = (c: Company) => c.id !== coId ? c : { ...c, submissions: { ...c.submissions, [k]: isSub } };
    setCos((prev) => prev.map(update));
    setSel((s) => s ? update(s) : s);
    if (isSub) {
      await supabase.from("submissions").insert({ company_id: coId, report_key: k, submitted: true });
    } else {
      await supabase.from("submissions").delete().eq("company_id", coId).eq("report_key", k);
    }
  }

  function getStats() {
    let totalReports = 0, submitted = 0, due = 0, overdue = 0;
    cos.forEach((co) => {
      const rpts = getRpts(co.regime);
      (["tax", "fin", "stat", "hr"] as const).forEach((cat) => {
        (rpts[cat] || []).forEach((r) => {
          if (r.type === "event") return;
          totalReports++;
          const k = `${r.id}__${gPK(r)}`;
          if (co.submissions[k]) { submitted++; return; }
          const d = dTo(gDL(r));
          if (d < 0) overdue++;
          else if (d <= 7) due++;
        });
      });
    });
    return { totalReports, submitted, due, overdue };
  }

  function getAlerts() {
    const a: { coName: string; rName: string; days: number }[] = [];
    cos.forEach((co) => {
      const rpts = getRpts(co.regime);
      (["tax", "fin", "stat", "hr"] as const).forEach((cat) => {
        (rpts[cat] || []).forEach((r) => {
          if (r.type === "event") return;
          const p = gPK(r), k = `${r.id}__${p}`;
          if (co.submissions[k]) return;
          const d = dTo(gDL(r));
          if (d === 1 || d === 3) a.push({ coName: co.name, rName: r[lang] || r.ru, days: d });
        });
      });
    });
    return a;
  }

  if (!ready) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#f4f4f5]">
        <div className="w-8 h-8 border-2 border-gray-900 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!session) return <LoginPage onLogin={doLogin} lang={lang} setLang={setLang} t={t} />;

  const stats = getStats();
  const alerts = getAlerts();
  const submissionRate = stats.totalReports ? Math.round((stats.submitted / stats.totalReports) * 100) : 0;

  return (
    <div className="flex h-screen bg-[#f4f4f5] overflow-hidden">
      <Sidebar lang={lang} setLang={setLang} page={page}
        setPage={(p: string) => { setPage(p); if (p !== "co") setSel(null); }}
        onLogout={doLogout} t={t} email={session.user.email || ""}
      />
      <div className="flex-1 flex flex-col overflow-hidden">
        <Topbar t={t} search={search} setSearch={setSearch} email={session.user.email || ""} />
        <main className="flex-1 overflow-y-auto p-6">
          {page === "dash" && (
            <DashPage cos={cos} stats={stats} alerts={alerts} submissionRate={submissionRate}
              t={t} lang={lang}
              onSel={(co) => { setSel(co); setPage("co"); }}
              onAdd={() => setModal(true)} onDel={delCo} search={search}
            />
          )}
          {page === "co" && sel && (
            <CoPage co={sel} t={t} lang={lang}
              onBack={() => { setPage("dash"); setSel(null); }}
              onToggle={(rid, p) => toggle(sel.id, rid, p)}
              onDel={() => delCo(sel.id)}
            />
          )}
          {page === "set" && (
            <div className="flex items-center justify-center h-full text-gray-400 text-sm">
              {t.nav.set}
            </div>
          )}
        </main>
      </div>
      {modal && <AddModal t={t} onAdd={addCo} onClose={() => setModal(false)} />}
    </div>
  );
}

// ── Login ─────────────────────────────────────────────────────────────────────
function LoginPage({ onLogin, lang, setLang, t }: {
  onLogin: (e: string, p: string, s: boolean) => Promise<boolean>;
  lang: Lang; setLang: (l: Lang) => void; t: typeof T[Lang];
}) {
  const [email, setEmail] = useState("");
  const [pwd, setPwd] = useState("");
  const [err, setErr] = useState("");
  const [load, setLoad] = useState(false);
  const [mode, setMode] = useState<"login" | "signup">("login");

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setLoad(true); setErr("");
    const ok = await onLogin(email.trim(), pwd, mode === "signup");
    if (!ok) { setErr(t.err); setLoad(false); }
  }

  return (
    <div className="min-h-screen flex bg-[#f4f4f5]">
      <div className="hidden lg:flex w-1/2 bg-gray-900 flex-col justify-between p-12">
        <div className="text-white text-2xl font-bold tracking-tight">{t.app}</div>
        <div>
          <div className="text-white text-4xl font-semibold leading-tight mb-4">
            {lang === "ru" && <>Управляйте<br />отчётами легко</>}
            {lang === "uz" && <>Hisobotlarni<br />oson boshqaring</>}
            {lang === "en" && <>Manage your<br />reports with ease</>}
          </div>
          <p className="text-gray-400 text-sm">
            {lang === "ru" && "Все налоговые, финансовые и кадровые отчёты в одном месте."}
            {lang === "uz" && "Barcha soliq, moliyaviy va kadrlar hisobotlari bir joyda."}
            {lang === "en" && "All tax, financial, and HR reports in one place."}
          </p>
        </div>
        <div className="flex gap-2">
          {(["ru", "uz", "en"] as Lang[]).map((l) => (
            <button key={l} onClick={() => setLang(l)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${lang === l ? "bg-white text-gray-900" : "bg-gray-800 text-gray-400 hover:bg-gray-700"}`}>
              {l.toUpperCase()}
            </button>
          ))}
        </div>
      </div>
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-sm">
          <div className="mb-8">
            <div className="lg:hidden text-2xl font-bold text-gray-900 mb-1">{t.app}</div>
            <h2 className="text-2xl font-semibold text-gray-900">{mode === "login" ? t.login : t.signup}</h2>
            <p className="text-gray-500 text-sm mt-1">{mode === "login" ? t.switchToSignup.split("?")[0] + "?" : ""}</p>
          </div>
          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">{t.uname}</label>
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com" required autoFocus
                className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-sm bg-white outline-none focus:border-gray-900 transition-colors" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1.5">{t.pwd}</label>
              <input type="password" value={pwd} onChange={(e) => setPwd(e.target.value)}
                placeholder="••••••" required minLength={6}
                className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-sm bg-white outline-none focus:border-gray-900 transition-colors" />
            </div>
            {err && <p className="text-red-500 text-xs bg-red-50 px-3 py-2 rounded-lg">{err}</p>}
            <button type="submit" disabled={load}
              className="w-full bg-gray-900 text-white py-2.5 rounded-xl text-sm font-medium hover:bg-gray-800 transition-colors disabled:opacity-50">
              {load ? "..." : mode === "login" ? t.login : t.signup}
            </button>
          </form>
          <button onClick={() => { setMode(mode === "login" ? "signup" : "login"); setErr(""); }}
            className="w-full text-center text-sm text-gray-500 mt-4 hover:text-gray-900 transition-colors">
            {mode === "login" ? t.switchToSignup : t.switchToLogin}
          </button>
          <div className="flex justify-center gap-2 mt-6 lg:hidden">
            {(["ru", "uz", "en"] as Lang[]).map((l) => (
              <button key={l} onClick={() => setLang(l)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-colors ${lang === l ? "bg-gray-900 text-white border-gray-900" : "bg-white text-gray-500 border-gray-200"}`}>
                {l.toUpperCase()}
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Sidebar ───────────────────────────────────────────────────────────────────
function Sidebar({ lang, setLang, page, setPage, onLogout, t, email }: {
  lang: Lang; setLang: (l: Lang) => void; page: string;
  setPage: (p: string) => void; onLogout: () => void;
  t: typeof T[Lang]; email: string;
}) {
  const nav = [
    { key: "dash", icon: <LayoutDashboard size={18} />, label: t.nav.dash },
    { key: "co", icon: <Building2 size={18} />, label: t.nav.cos },
    { key: "set", icon: <Settings size={18} />, label: t.nav.set },
  ];
  const isActive = (key: string) => page === key || (key === "co" && page === "co");
  return (
    <div className="w-56 bg-white border-r border-gray-100 flex flex-col flex-shrink-0">
      <div className="p-5 border-b border-gray-100">
        <span className="text-lg font-bold text-gray-900 tracking-tight">{t.app}</span>
      </div>
      <nav className="flex-1 p-3 space-y-0.5">
        {nav.map((item) => (
          <button key={item.key} onClick={() => setPage(item.key)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-colors ${isActive(item.key) ? "bg-gray-900 text-white" : "text-gray-500 hover:bg-gray-50 hover:text-gray-900"}`}>
            {item.icon}{item.label}
          </button>
        ))}
      </nav>
      <div className="p-3 border-t border-gray-100 space-y-3">
        <div className="flex gap-1">
          {(["ru", "uz", "en"] as Lang[]).map((l) => (
            <button key={l} onClick={() => setLang(l)}
              className={`flex-1 py-1 rounded-lg text-[11px] font-medium transition-colors ${lang === l ? "bg-gray-900 text-white" : "text-gray-400 hover:text-gray-700"}`}>
              {l.toUpperCase()}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-2.5 px-1">
          <div className="w-7 h-7 rounded-full bg-gray-900 flex items-center justify-center text-white text-xs font-semibold flex-shrink-0">
            {(email[0] || "U").toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs text-gray-900 font-medium truncate">{email}</p>
          </div>
          <button onClick={onLogout} className="text-gray-400 hover:text-gray-700 transition-colors" title={t.logout}>
            <LogOut size={15} />
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Topbar ────────────────────────────────────────────────────────────────────
function Topbar({ t, search, setSearch, email }: {
  t: typeof T[Lang]; search: string; setSearch: (v: string) => void; email: string;
}) {
  return (
    <div className="h-14 bg-white border-b border-gray-100 flex items-center px-6 gap-4 flex-shrink-0">
      <div className="flex-1 relative max-w-xs">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder={t.search}
          className="w-full pl-9 pr-3 py-2 bg-[#f4f4f5] rounded-xl text-sm outline-none focus:ring-1 focus:ring-gray-200 text-gray-700 placeholder-gray-400" />
      </div>
      <div className="flex items-center gap-3 ml-auto">
        <button className="relative w-8 h-8 flex items-center justify-center rounded-xl hover:bg-gray-100 transition-colors text-gray-500">
          <Bell size={17} />
        </button>
        <div className="w-8 h-8 rounded-full bg-gray-900 flex items-center justify-center text-white text-xs font-semibold">
          {(email[0] || "U").toUpperCase()}
        </div>
      </div>
    </div>
  );
}

// ── Dashboard ─────────────────────────────────────────────────────────────────
function DashPage({ cos, stats, alerts, submissionRate, t, lang, onSel, onAdd, onDel, search }: {
  cos: Company[]; stats: ReturnType<() => { totalReports: number; submitted: number; due: number; overdue: number }>;
  alerts: { coName: string; rName: string; days: number }[]; submissionRate: number;
  t: typeof T[Lang]; lang: Lang;
  onSel: (co: Company) => void; onAdd: () => void; onDel: (id: string) => void; search: string;
}) {
  const now = new Date();
  const barData = getBarData(cos, t.ms);
  const maxBar = Math.max(...barData.map((b) => b.value), 1);
  const filtered = cos.filter((c) =>
    !search || c.name.toLowerCase().includes(search.toLowerCase()) || c.inn.includes(search)
  );

  const statCards = [
    { label: t.st.cos, value: cos.length, icon: <Building2 size={20} />, dark: true },
    { label: t.st.due, value: stats.due, icon: <Clock size={20} />, dark: false },
    { label: t.st.done, value: stats.submitted, icon: <CheckCircle2 size={20} />, dark: false },
    { label: t.st.overdue, value: stats.overdue, icon: <AlertTriangle size={20} />, dark: false },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">{t.nav.dash}</h1>
        <button onClick={onAdd}
          className="flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-gray-800 transition-colors">
          <Plus size={16} />{t.addCo}
        </button>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-4 gap-4">
        {statCards.map((s, i) => (
          <div key={i} className={`rounded-2xl p-5 ${s.dark ? "bg-gray-900 text-white" : "bg-white border border-gray-100"}`}>
            <div className={`flex items-center justify-between mb-3 ${s.dark ? "text-gray-400" : "text-gray-400"}`}>
              <span className="text-xs font-medium">{s.label}</span>
              {s.icon}
            </div>
            <div className={`text-3xl font-semibold ${s.dark ? "text-white" : "text-gray-900"}`}>{s.value}</div>
            <div className={`flex items-center gap-1 mt-1 text-xs ${s.dark ? "text-gray-400" : "text-gray-400"}`}>
              <TrendingUp size={12} />
              <span>{t.fromLastMonth}</span>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-4">
        {/* Bar chart */}
        <div className="col-span-2 bg-white rounded-2xl border border-gray-100 p-5">
          <div className="flex items-center justify-between mb-5">
            <h3 className="text-sm font-semibold text-gray-900">{t.recentActivity}</h3>
          </div>
          <div className="flex items-end gap-3 h-36">
            {barData.map((b, i) => {
              const isLast = i === barData.length - 1;
              const pct = (b.value / maxBar) * 100;
              return (
                <div key={i} className="flex-1 flex flex-col items-center gap-1.5">
                  <div className="w-full flex items-end" style={{ height: 112 }}>
                    <div
                      className={`w-full rounded-t-lg transition-all ${isLast ? "bg-gray-900" : "bg-gray-200"}`}
                      style={{ height: `${Math.max(pct, 4)}%` }}
                    />
                  </div>
                  <span className="text-[11px] text-gray-400">{b.label}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Submission rate */}
        <div className="bg-white rounded-2xl border border-gray-100 p-5 flex flex-col">
          <h3 className="text-sm font-semibold text-gray-900 mb-4">{t.submissionRate}</h3>
          <div className="flex-1 flex flex-col items-center justify-center gap-3">
            <div className="relative w-24 h-24">
              <svg viewBox="0 0 36 36" className="w-full h-full -rotate-90">
                <circle cx="18" cy="18" r="15.9" fill="none" stroke="#f3f4f6" strokeWidth="3" />
                <circle cx="18" cy="18" r="15.9" fill="none" stroke="#111827" strokeWidth="3"
                  strokeDasharray={`${submissionRate} ${100 - submissionRate}`} strokeLinecap="round" />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-xl font-bold text-gray-900">{submissionRate}%</span>
              </div>
            </div>
            <div className="flex items-center gap-1 text-xs text-green-600">
              <TrendingUp size={12} />
              <span>{t.fromLastMonth}</span>
            </div>
          </div>
          {alerts.length > 0 && (
            <div className="mt-3 space-y-1.5">
              {alerts.slice(0, 3).map((a, i) => (
                <div key={i} className="flex items-start gap-2 p-2 bg-amber-50 rounded-lg">
                  <AlertTriangle size={13} className="text-amber-500 mt-0.5 flex-shrink-0" />
                  <p className="text-[11px] text-amber-700 leading-snug">
                    <strong>{a.coName}</strong> — {a.days <= 1 ? t.d1 : t.d3}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Companies table */}
      <div className="bg-white rounded-2xl border border-gray-100">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h3 className="text-sm font-semibold text-gray-900">{t.nav.cos}</h3>
        </div>
        {filtered.length === 0 ? (
          <div className="py-16 text-center">
            <Building2 size={40} className="mx-auto text-gray-200 mb-3" />
            <p className="text-sm font-medium text-gray-500">{t.noCos}</p>
            <p className="text-xs text-gray-400 mt-1">{t.addF}</p>
          </div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="text-xs text-gray-400 font-medium">
                <th className="text-left px-5 py-3">{t.coName}</th>
                <th className="text-left px-5 py-3">{t.inn}</th>
                <th className="text-left px-5 py-3">{t.regime}</th>
                <th className="text-left px-5 py-3">{t.st.done}</th>
                <th className="text-left px-5 py-3">{t.status}</th>
                <th className="px-5 py-3" />
              </tr>
            </thead>
            <tbody>
              {filtered.map((co) => {
                const rpts = getRpts(co.regime);
                let total = 0, sub = 0, urgent = 0;
                (["tax", "fin", "stat", "hr"] as const).forEach((cat) => {
                  (rpts[cat] || []).forEach((r) => {
                    if (r.type === "event") return;
                    total++;
                    const k = `${r.id}__${gPK(r)}`;
                    if (co.submissions[k]) sub++;
                    else { const d = dTo(gDL(r)); if (d < 0) urgent++; else if (d <= 3) urgent++; }
                  });
                });
                const pct = total ? Math.round((sub / total) * 100) : 0;
                const allDone = sub === total;
                return (
                  <tr key={co.id} className="border-t border-gray-50 hover:bg-gray-50/50 transition-colors group">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-gray-100 flex items-center justify-center flex-shrink-0">
                          <Building2 size={15} className="text-gray-500" />
                        </div>
                        <span className="text-sm font-medium text-gray-900">{co.name}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5 text-sm text-gray-500">{co.inn}</td>
                    <td className="px-5 py-3.5">
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${co.regime === "general" ? "bg-blue-50 text-blue-700" : "bg-green-50 text-green-700"}`}>
                        {co.regime === "general" ? t.gen : t.sim}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2">
                        <div className="w-20 h-1.5 bg-gray-100 rounded-full overflow-hidden">
                          <div className={`h-full rounded-full ${allDone ? "bg-green-500" : urgent > 0 ? "bg-amber-400" : "bg-gray-900"}`}
                            style={{ width: `${pct}%` }} />
                        </div>
                        <span className="text-xs text-gray-500">{sub}/{total}</span>
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${allDone ? "bg-green-50 text-green-700" : urgent > 0 ? "bg-red-50 text-red-600" : "bg-gray-100 text-gray-600"}`}>
                        {allDone ? <><CheckCircle2 size={11} />{t.allDone}</> : urgent > 0 ? <><AlertTriangle size={11} />{t.over}</> : <><Clock size={11} />{t.noSub}</>}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2 justify-end opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onClick={() => onSel(co)}
                          className="px-3 py-1.5 bg-gray-900 text-white rounded-lg text-xs font-medium hover:bg-gray-800 transition-colors">
                          {t.open}
                        </button>
                        <button onClick={() => { if (confirm(t.delQ)) onDel(co.id); }}
                          className="w-7 h-7 flex items-center justify-center rounded-lg text-gray-400 hover:bg-red-50 hover:text-red-500 transition-colors">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ── Company detail ─────────────────────────────────────────────────────────────
function CoPage({ co, t, lang, onBack, onToggle, onDel }: {
  co: Company; t: typeof T[Lang]; lang: Lang;
  onBack: () => void; onToggle: (rid: string, p: string) => void; onDel: () => void;
}) {
  const [tab, setTab] = useState<TabKey>("tax");
  const rpts = getRpts(co.regime);
  const tabs = [
    { key: "tax" as TabKey, label: t.tabs.tax },
    { key: "fin" as TabKey, label: t.tabs.fin },
    { key: "stat" as TabKey, label: t.tabs.stat },
    { key: "hr" as TabKey, label: t.tabs.hr },
  ];
  const list = rpts[tab] || [];

  let total = 0, sub = 0;
  (["tax", "fin", "stat", "hr"] as const).forEach((cat) => {
    (rpts[cat] || []).forEach((r) => {
      if (r.type === "event") return;
      total++;
      const k = `${r.id}__${gPK(r)}`;
      if (co.submissions[k]) sub++;
    });
  });
  const pct = total ? Math.round((sub / total) * 100) : 0;

  return (
    <div className="space-y-5">
      <button onClick={onBack} className="flex items-center gap-1.5 text-sm text-gray-500 hover:text-gray-900 transition-colors">
        <ChevronLeft size={16} />{t.back}
      </button>

      <div className="bg-white rounded-2xl border border-gray-100 p-5">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-gray-100 flex items-center justify-center">
              <Building2 size={22} className="text-gray-600" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">{co.name}</h2>
              <p className="text-sm text-gray-500 mt-0.5">{t.inn}: {co.inn} · {co.regime === "general" ? t.gen : t.sim}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right">
              <p className="text-2xl font-bold text-gray-900">{pct}%</p>
              <p className="text-xs text-gray-400">{sub} {t.of} {total}</p>
            </div>
            <button onClick={() => { if (confirm(t.delQ)) onDel(); }}
              className="flex items-center gap-2 px-3 py-2 rounded-xl border border-gray-200 text-sm text-red-500 hover:bg-red-50 transition-colors">
              <Trash2 size={15} />{t.delCo}
            </button>
          </div>
        </div>
        <div className="mt-4 h-1.5 bg-gray-100 rounded-full overflow-hidden">
          <div className="h-full bg-gray-900 rounded-full transition-all" style={{ width: `${pct}%` }} />
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100">
        <div className="flex border-b border-gray-100 px-2 pt-2">
          {tabs.map((tb) => (
            <button key={tb.key} onClick={() => setTab(tb.key)}
              className={`px-4 py-2.5 text-sm font-medium rounded-t-lg transition-colors ${tab === tb.key ? "text-gray-900 border-b-2 border-gray-900" : "text-gray-400 hover:text-gray-700"}`}>
              {tb.label}
            </button>
          ))}
        </div>

        {list.length === 0 ? (
          <div className="py-12 text-center text-sm text-gray-400">—</div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="text-xs text-gray-400 font-medium">
                <th className="text-left px-5 py-3 w-8"></th>
                <th className="text-left px-5 py-3">{t.report}</th>
                <th className="text-left px-5 py-3">{t.frequency}</th>
                <th className="text-left px-5 py-3">{t.deadline}</th>
                <th className="text-left px-5 py-3">{t.status}</th>
              </tr>
            </thead>
            <tbody>
              {list.map((r) => {
                const p = gPK(r), k = `${r.id}__${p}`;
                const isSub = !!co.submissions[k];
                const dl = r.type !== "event" ? gDL(r) : null;
                const days = dl ? dTo(dl) : null;
                const rName = r[lang] || r.ru;
                const freq = r.type === "monthly" ? t.monthly : r.type === "quarterly" ? t.quarterly : r.type === "annual" ? t.annual : t.event;
                let statusEl;
                if (isSub) {
                  statusEl = <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-green-50 text-green-700"><CheckCircle2 size={11} />{t.sub}</span>;
                } else if (days !== null && days < 0) {
                  statusEl = <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-red-50 text-red-600"><AlertTriangle size={11} />{t.over}</span>;
                } else if (days !== null && days <= 1) {
                  statusEl = <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-amber-50 text-amber-600"><Clock size={11} />{t.d1}</span>;
                } else if (days !== null && days <= 3) {
                  statusEl = <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-amber-50 text-amber-600"><Clock size={11} />{t.d3}</span>;
                } else {
                  statusEl = <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-500"><Clock size={11} />{t.noSub}</span>;
                }
                return (
                  <tr key={r.id} className="border-t border-gray-50 hover:bg-gray-50/50 transition-colors">
                    <td className="px-5 py-3.5">
                      <div onClick={() => onToggle(r.id, p)}
                        className={`w-5 h-5 rounded-md border-2 flex items-center justify-center cursor-pointer transition-colors ${isSub ? "bg-gray-900 border-gray-900" : "border-gray-300 hover:border-gray-500"}`}>
                        {isSub && <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 12 12"><path d="M2 6l3 3 5-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" /></svg>}
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={`text-sm ${isSub ? "line-through text-gray-400" : "text-gray-900 font-medium"}`}>{rName}</span>
                    </td>
                    <td className="px-5 py-3.5 text-sm text-gray-500">{freq}</td>
                    <td className="px-5 py-3.5 text-sm text-gray-500">{dl && !isSub ? fD(dl, t.ms) : "—"}</td>
                    <td className="px-5 py-3.5">{statusEl}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

// ── Add company modal ─────────────────────────────────────────────────────────
function AddModal({ t, onAdd, onClose }: {
  t: typeof T[Lang];
  onAdd: (name: string, inn: string, regime: Regime) => void;
  onClose: () => void;
}) {
  const [name, setName] = useState("");
  const [inn, setInn] = useState("");
  const [regime, setRegime] = useState<Regime>("general");

  return (
    <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-md p-6 shadow-xl">
        <div className="flex items-center justify-between mb-5">
          <h3 className="text-base font-semibold text-gray-900">{t.addCo}</h3>
          <button onClick={onClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-gray-100 text-gray-400 transition-colors">
            <X size={16} />
          </button>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">{t.coName}</label>
            <input value={name} onChange={(e) => setName(e.target.value)}
              placeholder='ООО "Название"' autoFocus
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-gray-900 transition-colors" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">{t.inn}</label>
            <input value={inn} onChange={(e) => setInn(e.target.value)} placeholder="300000001"
              className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-gray-900 transition-colors" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1.5">{t.regime}</label>
            <div className="relative">
              <select value={regime} onChange={(e) => setRegime(e.target.value as Regime)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-gray-200 text-sm outline-none focus:border-gray-900 transition-colors appearance-none bg-white">
                <option value="general">{t.gen}</option>
                <option value="simplified">{t.sim}</option>
              </select>
              <ChevronDown size={15} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" />
            </div>
          </div>
        </div>
        <div className="flex gap-3 mt-6">
          <button onClick={onClose}
            className="flex-1 px-4 py-2.5 rounded-xl border border-gray-200 text-sm font-medium text-gray-700 hover:bg-gray-50 transition-colors">
            {t.cancel}
          </button>
          <button onClick={() => { if (name.trim()) onAdd(name.trim(), inn.trim(), regime); }}
            disabled={!name.trim()}
            className="flex-1 px-4 py-2.5 rounded-xl bg-gray-900 text-white text-sm font-medium hover:bg-gray-800 transition-colors disabled:opacity-40">
            {t.save}
          </button>
        </div>
      </div>
    </div>
  );
}
