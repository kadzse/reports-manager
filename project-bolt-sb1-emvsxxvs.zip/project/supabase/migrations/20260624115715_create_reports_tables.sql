CREATE TABLE companies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  inn text NOT NULL,
  regime text NOT NULL DEFAULT 'general',
  user_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  report_key text NOT NULL,
  submitted boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, report_key)
);

ALTER TABLE companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_companies" ON companies FOR SELECT
  TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "insert_own_companies" ON companies FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_companies" ON companies FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_companies" ON companies FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE POLICY "select_own_submissions" ON submissions FOR SELECT
  TO authenticated USING (auth.uid() = (SELECT user_id FROM companies WHERE id = company_id));
CREATE POLICY "insert_own_submissions" ON submissions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = (SELECT user_id FROM companies WHERE id = company_id));
CREATE POLICY "update_own_submissions" ON submissions FOR UPDATE
  TO authenticated USING (auth.uid() = (SELECT user_id FROM companies WHERE id = company_id))
  WITH CHECK (auth.uid() = (SELECT user_id FROM companies WHERE id = company_id));
CREATE POLICY "delete_own_submissions" ON submissions FOR DELETE
  TO authenticated USING (auth.uid() = (SELECT user_id FROM companies WHERE id = company_id));
